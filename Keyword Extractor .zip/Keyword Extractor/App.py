from flask import Flask, request, jsonify, render_template
from sklearn.feature_extraction.text import TfidfVectorizer
import re

app = Flask(__name__)

STOP_WORDS = {
    "a", "an", "the", "and", "or", "but", "if", "then",
    "is", "are", "was", "were", "be", "been", "being",
    "to", "of", "in", "on", "at", "for", "from", "with",
    "by", "about", "as", "into", "through", "during",
    "this", "that", "these", "those", "it", "its",
    "he", "she", "they", "we", "you", "i", "me", "my",
    "your", "our", "their", "his", "her", "have", "has",
    "had", "do", "does", "did", "will", "would", "can",
    "could", "should", "may", "might", "must", "not",
    "very", "also", "than", "which", "who", "what",
    "where", "when", "how", "all", "each", "both",
    "more", "most", "some", "such", "only", "other",
    "over", "under", "again", "further", "once",
    "here", "there", "while", "because", "before",
    "after", "between", "without", "within", "about"
}




def clean_text(text):
    """
    Clean input text before keyword extraction.
    """

   
    text = text.lower()

   
    text = re.sub(
        r"https?://\S+|www\.\S+",
        " ",
        text
    )

   
    text = re.sub(
        r"\S+@\S+",
        " ",
        text
    )

   
    text = re.sub(
        r"[^a-zA-Z\s]",
        " ",
        text
    )

   
    text = re.sub(
        r"\s+",
        " ",
        text
    ).strip()

    return text




def extract_keywords(text, top_n=10):

    cleaned_text = clean_text(text)

    if not cleaned_text:
        return []

    
    vectorizer = TfidfVectorizer(
        stop_words=list(STOP_WORDS),
        ngram_range=(1, 3),
        max_features=200,
        token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z]+\b"
    )

    try:
        matrix = vectorizer.fit_transform(
            [cleaned_text]
        )

    except ValueError:
        return []

    feature_names = vectorizer.get_feature_names_out()

    scores = matrix.toarray()[0]

    keywords = []

    for keyword, score in zip(
        feature_names,
        scores
    ):

        
        if score <= 0:
            continue

        
        individual_words = keyword.split()

        if any(
            len(word) < 3
            for word in individual_words
        ):
            continue

        keywords.append({
            "keyword": keyword.title(),
            "score": round(
                float(score),
                4
            )
        })

    
    keywords.sort(
        key=lambda item: item["score"],
        reverse=True
    )

    
    keywords = keywords[:top_n]

    
    if keywords:

        highest_score = keywords[0]["score"]

        for item in keywords:

            percentage = (
                item["score"]
                / highest_score
            ) * 100

            item["percentage"] = round(
                percentage,
                1
            )

    return keywords




@app.route("/")
def home():

    return render_template(
        "index.html"
    )




@app.route(
    "/extract",
    methods=["POST"]
)
def extract():

    try:

        data = request.get_json()

        if not data:

            return jsonify({
                "success": False,
                "message": "No data received."
            }), 400


        text = data.get(
            "text",
            ""
        )


        if not isinstance(
            text,
            str
        ):

            return jsonify({
                "success": False,
                "message": "Invalid text format."
            }), 400


        text = text.strip()


        if not text:

            return jsonify({
                "success": False,
                "message": "Please enter some text."
            }), 400


        
        keywords = extract_keywords(
            text,
            top_n=10
        )


        
        words = text.split()

        characters = len(text)

        sentences = len(
            re.findall(
                r"[.!?]+",
                text
            )
        )


        if sentences == 0:
            sentences = 1


        return jsonify({

            "success": True,

            "keywords": keywords,

            "total_words": len(words),

            "total_characters": characters,

            "total_sentences": sentences,

            "total_keywords": len(
                keywords
            )

        })


    except Exception as error:

        print(
            "Error:",
            error
        )

        return jsonify({

            "success": False,

            "message":
                "Something went wrong while processing the text."

        }), 500




if __name__ == "__main__":

    app.run(
        debug=True
    )